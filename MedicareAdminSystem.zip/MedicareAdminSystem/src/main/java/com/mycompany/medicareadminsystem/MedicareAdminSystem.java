/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.medicareadminsystem;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.*;
// Enum for patient categories
enum PatientCategory {
    INPATIENT, OUTPATIENT, EMERGENCY
}
//Base Patient Class
class Patient {
    private String patientId;
    private String firstName;
    private String lastName;
    private int age;
    private String gender;
    private String medicalCondition;
    private PatientCategory category;
    
    // Constructors
    public Patient() {}
    
    public Patient(String patientId, String firstName, String lastName, int age,
                   String gender, String medicalCondition, PatientCategory category) {
        this.patientId = patientId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.age = age;
        this.gender = gender;
        this.medicalCondition = medicalCondition;
        this.category = category;
    }
    
    // Getters and Setters
    public String getPatientId() { return patientId; }
    public void setPatientId(String patientId) { this.patientId = patientId; }

    public String getFirstName() { return firstName; }
    public void setFirstName(String firstName) { this.firstName = firstName; }

    public String getLastName() { return lastName; }
    public void setLastName(String lastName) { this.lastName = lastName; }

    public int getAge() { return age; }
    public void setAge(int age) { this.age = age; }

    public String getGender() { return gender; }
    public void setGender(String gender) { this.gender = gender; }

    public String getMedicalCondition() { return medicalCondition; }
    public void setMedicalCondition(String medicalCondition) { this.medicalCondition = medicalCondition; }

    public PatientCategory getCategory() { return category; }
    public void setCategory(PatientCategory category) { this.category = category; }

    // Display details (can be overridden)
    public String displayDetails() {
        return String.format("ID: %s | Name: %s %s | Age: %d | Gender: %s | Condition: %s | Category: %s",
                patientId, firstName, lastName, age, gender, medicalCondition, category);
    }

    @Override
    public String toString() {
        return displayDetails();
    }
}

// Inpatient class (extends Patient)
class Inpatient extends Patient {
    private String wardNumber;
    private String bedNumber;

    public Inpatient(String patientId, String firstName, String lastName, int age,
                     String gender, String medicalCondition,
                     String wardNumber, String bedNumber) {
        super(patientId, firstName, lastName, age, gender, medicalCondition, PatientCategory.INPATIENT);
        this.wardNumber = wardNumber;
        this.bedNumber = bedNumber;
    }

    public String getWardNumber() { return wardNumber; }
    public void setWardNumber(String wardNumber) { this.wardNumber = wardNumber; }

    public String getBedNumber() { return bedNumber; }
    public void setBedNumber(String bedNumber) { this.bedNumber = bedNumber; }

    @Override
    public String displayDetails() {
        return super.displayDetails() + String.format(" | Ward: %s | Bed: %s", wardNumber, bedNumber);
    }
}

// Bed class (represents a single bed)
class Bed {
    private String bedNumber;
    private String occupiedByPatientId; // null if free

    public Bed(String bedNumber) {
        this.bedNumber = bedNumber;
        this.occupiedByPatientId = null;
    }

    public String getBedNumber() { return bedNumber; }
    public String getOccupiedByPatientId() { return occupiedByPatientId; }
    public boolean isOccupied() { return occupiedByPatientId != null; }

    public void occupy(String patientId) {
        this.occupiedByPatientId = patientId;
    }

    public void release() {
        this.occupiedByPatientId = null;
    }

    @Override
    public String toString() {
        return bedNumber + (isOccupied() ? " (Occupied)" : " (Available)");
    }
}

// BedManager – manages 20 beds in a 4x5 layout
class BedManager {
    private static final int ROWS = 4;
    private static final int COLS = 5;
    private static final int TOTAL_BEDS = ROWS * COLS;
    private Bed[][] beds;

    public BedManager() {
        beds = new Bed[ROWS][COLS];
        int num = 1;
        for (int r = 0; r < ROWS; r++) {
            for (int c = 0; c < COLS; c++) {
                String bedNumber = String.format("B%02d", num++);
                beds[r][c] = new Bed(bedNumber);
            }
        }
    }

    // Allocate available bed to an inpatient
    public String allocateBed(String patientId) {
        for (int r = 0; r < ROWS; r++) {
            for (int c = 0; c < COLS; c++) {
                if (!beds[r][c].isOccupied()) {
                    beds[r][c].occupy(patientId);
                    return beds[r][c].getBedNumber();
                }
            }
        }
        return null; // no bed available
    }

    // Release a bed by bed number
    public boolean releaseBed(String bedNumber) {
        for (int r = 0; r < ROWS; r++) {
            for (int c = 0; c < COLS; c++) {
                if (beds[r][c].getBedNumber().equalsIgnoreCase(bedNumber)) {
                    if (beds[r][c].isOccupied()) {
                        beds[r][c].release();
                        return true;
                    } else {
                        return false; // bed already free
                    }
                }
            }
        }
        return false; // bed not found
    }

    // Release a bed by patient ID (to find which bed the patient occupies)
    public boolean releaseBedByPatientId(String patientId) {
        for (int r = 0; r < ROWS; r++) {
            for (int c = 0; c < COLS; c++) {
                if (beds[r][c].isOccupied() && beds[r][c].getOccupiedByPatientId().equals(patientId)) {
                    beds[r][c].release();
                    return true;
                }
            }
        }
        return false;
    }

    // Display complete ward layout
    public void displayWardLayout() {
        System.out.println("\n===== WARD LAYOUT (4x5) =====");
        for (int r = 0; r < ROWS; r++) {
            for (int c = 0; c < COLS; c++) {
                Bed bed = beds[r][c];
                String status = bed.isOccupied() ? "[X]" : "[ ]";
                System.out.printf("%s %-5s", bed.getBedNumber(), status);
            }
            System.out.println();
        }
        System.out.println("Legend: [X] Occupied, [ ] Available");
    }

    // Display available beds
    public List<String> getAvailableBedNumbers() {
        List<String> available = new ArrayList<>();
        for (int r = 0; r < ROWS; r++) {
            for (int c = 0; c < COLS; c++) {
                if (!beds[r][c].isOccupied()) {
                    available.add(beds[r][c].getBedNumber());
                }
            }
        }
        return available;
    }

    public void displayAvailableBeds() {
        List<String> avail = getAvailableBedNumbers();
        if (avail.isEmpty()) {
            System.out.println("No available beds.");
        } else {
            System.out.println("Available beds: " + String.join(", ", avail));
        }
    }

    // Display occupied beds
    public List<String> getOccupiedBedNumbers() {
        List<String> occupied = new ArrayList<>();
        for (int r = 0; r < ROWS; r++) {
            for (int c = 0; c < COLS; c++) {
                if (beds[r][c].isOccupied()) {
                    occupied.add(beds[r][c].getBedNumber());
                }
            }
        }
        return occupied;
    }

    public void displayOccupiedBeds() {
        List<String> occ = getOccupiedBedNumbers();
        if (occ.isEmpty()) {
            System.out.println("No occupied beds.");
        } else {
            System.out.println("Occupied beds: " + String.join(", ", occ));
        }
    }

    public int getOccupiedCount() {
        int count = 0;
        for (int r = 0; r < ROWS; r++) {
            for (int c = 0; c < COLS; c++) {
                if (beds[r][c].isOccupied()) count++;
            }
        }
        return count;
    }

    public double getOccupancyPercentage() {
        return (getOccupiedCount() * 100.0) / TOTAL_BEDS;
    }

    public int getTotalBeds() {
        return TOTAL_BEDS;
    }

    // Check if a bed is occupied
    public boolean isBedOccupied(String bedNumber) {
        for (int r = 0; r < ROWS; r++) {
            for (int c = 0; c < COLS; c++) {
                if (beds[r][c].getBedNumber().equalsIgnoreCase(bedNumber)) {
                    return beds[r][c].isOccupied();
                }
            }
        }
        return false; // bed not found
    }

    // Get bed number occupied by a patient (if any)
    public String getBedNumberByPatientId(String patientId) {
        for (int r = 0; r < ROWS; r++) {
            for (int c = 0; c < COLS; c++) {
                if (beds[r][c].isOccupied() && beds[r][c].getOccupiedByPatientId().equals(patientId)) {
                    return beds[r][c].getBedNumber();
                }
            }
        }
        return null;
    }
}

// PatientManager – manages list of patients
class PatientManager {
    private List<Patient> patients;

    public PatientManager() {
        patients = new ArrayList<>();
    }

    // Register a new patient (apply9 exception if duplicate ID)
    public void registerPatient(Patient patient) throws IllegalArgumentException {
        if (findPatientById(patient.getPatientId()) != null) {
            throw new IllegalArgumentException("Patient ID already exists: " + patient.getPatientId());
        }
        patients.add(patient);
    }

    // Search by ID
    public Patient findPatientById(String patientId) {
        for (Patient p : patients) {
            if (p.getPatientId().equalsIgnoreCase(patientId)) {
                return p;
            }
        }
        return null;
    }

    // Update patient details (returns true if successful)
    public boolean updatePatient(String patientId, Patient updatedPatient) {
        Patient existing = findPatientById(patientId);
        if (existing == null) return false;
        // Keep the same ID
        updatedPatient.setPatientId(patientId);
        // Replace in list
        int index = patients.indexOf(existing);
        patients.set(index, updatedPatient);
        return true;
    }

    // Delete patient by ID
    public boolean deletePatient(String patientId) {
        Patient p = findPatientById(patientId);
        if (p == null) return false;
        return patients.remove(p);
    }

    // Display all patients
    public void displayAllPatients() {
        if (patients.isEmpty()) {
            System.out.println("No registered patients.");
            return;
        }
        System.out.println("\n===== ALL REGISTERED PATIENTS =====");
        for (Patient p : patients) {
            System.out.println(p.displayDetails());
        }
    }

    public List<Patient> getAllPatients() {
        return new ArrayList<>(patients);
    }

    public int getTotalPatients() {
        return patients.size();
    }

    // Additional sort methods (used in tests)
    public List<Patient> sortByLastName() {
        List<Patient> sorted = new ArrayList<>(patients);
        sorted.sort(Comparator.comparing(Patient::getLastName));
        return sorted;
    }

    public List<Patient> sortByPatientId() {
        List<Patient> sorted = new ArrayList<>(patients);
        sorted.sort(Comparator.comparing(Patient::getPatientId));
        return sorted;
    }
}
// Main Administation System
public class MedicareAdminSystem {

    private static Scanner scanner = new Scanner(System.in);
    private static PatientManager patientManager = new PatientManager();
    private static BedManager bedManager = new BedManager();
    public static void main(String[] args) {
        System.out.println("=== MediCare Hospital Patient Admission System ===");
        boolean exit = false;
        while (!exit) {
            showMenu();
            int choice = readInt("Enter your option: ");
            switch (choice) {
                case 1: registerPatient(); break;
                case 2: searchPatient(); break;
                case 3: updatePatient(); break;
                case 4: deletePatient(); break;
                case 5: patientManager.displayAllPatients(); break;
                case 6: allocateBed(); break;
                case 7: releaseBed(); break;
                case 8: bedManager.displayWardLayout(); break;
                case 9: bedManager.displayAvailableBeds(); break;
                case 10: bedManager.displayOccupiedBeds(); break;
                case 11: generateReports(); break;
                case 0: exit = true; System.out.println("Exiting system. Goodbye!"); break;
                default: System.out.println("Invalid choice. Please try again.");
            }
        }
        scanner.close();
    }

    private static void showMenu() {
        System.out.println("\n--- MAIN MENU ---");
        System.out.println("1. Register a new patient");
        System.out.println("2. Search for a patient by ID");
        System.out.println("3. Update patient details");
        System.out.println("4. Delete a patient");
        System.out.println("5. Display all registered patients");
        System.out.println("6. Allocate a bed to an inpatient");
        System.out.println("7. Release a bed");
        System.out.println("8. Display ward layout");
        System.out.println("9. Display available beds");
        System.out.println("10. Display occupied beds");
        System.out.println("11. Generate reports");
        System.out.println("0. Exit");
    }

    private static int readInt(String prompt) {
        System.out.print(prompt);
        while (!scanner.hasNextInt()) {
            System.out.print("Invalid input. Please enter a number again: ");
            scanner.next();
        }
        int value = scanner.nextInt();
        scanner.nextLine(); // consume newline
        return value;
    }

    private static String readString(String prompt) {
        System.out.print(prompt);
        return scanner.nextLine().trim();
    }

    private static PatientCategory readCategory() {
        System.out.println("Select category: 1. INPATIENT  2. OUTPATIENT  3. EMERGENCY");
        int choice = readInt("Choice: ");
        switch (choice) {
            case 1: return PatientCategory.INPATIENT;
            case 2: return PatientCategory.OUTPATIENT;
            case 3: return PatientCategory.EMERGENCY;
            default: System.out.println("Invalid. Defaulting to OUTPATIENT."); return PatientCategory.OUTPATIENT;
        }
    }

    // System Feature methods 
    private static void registerPatient() {
        System.out.println("\n--- Register New Patient ---");
        String id = readString("Patient ID: ");
        if (patientManager.findPatientById(id) != null) {
            System.out.println("Error: Patient ID already exists.");
            return;
        }
        String firstName = readString("First Name: ");
        String lastName = readString("Last Name: ");
        int age = readInt("Age: ");
        String gender = readString("Gender: ");
        String condition = readString("Medical Condition: ");
        PatientCategory category = readCategory();

        Patient patient;
        if (category == PatientCategory.INPATIENT) {
            // For inpatients, bed will be allocated later (not here)
            patient = new Patient(id, firstName, lastName, age, gender, condition, category);
        } else {
            patient = new Patient(id, firstName, lastName, age, gender, condition, category);
        }
        try {
            patientManager.registerPatient(patient);
            System.out.println("Patient registered successfully.");
        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void searchPatient() {
        String id = readString("Enter Patient ID to search: ");
        Patient p = patientManager.findPatientById(id);
        if (p == null) {
            System.out.println("Patient not found.");
        } else {
            System.out.println(p.displayDetails());
        }
    }

    private static void updatePatient() {
        String id = readString("Enter Patient ID to update: ");
        Patient existing = patientManager.findPatientById(id);
        if (existing == null) {
            System.out.println("Patient not found.");
            return;
        }
        System.out.println("Current details: " + existing.displayDetails());
        System.out.println("Enter new details (leave blank to keep current):");
        String firstName = readString("First Name (" + existing.getFirstName() + "): ");
        if (!firstName.isEmpty()) existing.setFirstName(firstName);
        String lastName = readString("Last Name (" + existing.getLastName() + "): ");
        if (!lastName.isEmpty()) existing.setLastName(lastName);
        String ageStr = readString("Age (" + existing.getAge() + "): ");
        if (!ageStr.isEmpty()) existing.setAge(Integer.parseInt(ageStr));
        String gender = readString("Gender (" + existing.getGender() + "): ");
        if (!gender.isEmpty()) existing.setGender(gender);
        String condition = readString("Medical Condition (" + existing.getMedicalCondition() + "): ");
        if (!condition.isEmpty()) existing.setMedicalCondition(condition);
        // Category update is more complex; we skip for simplicity or allow?
        System.out.println("Category update is not supported in this simple update. You can delete and re-register if needed.");
        System.out.println("Patient details updated.");
    }

    private static void deletePatient() {
        String id = readString("Enter Patient ID to delete: ");
        // If patient is an inpatient and has a bed, release the bed first
        Patient p = patientManager.findPatientById(id);
        if (p == null) {
            System.out.println("Patient not found.");
            return;
        }
        if (p.getCategory() == PatientCategory.INPATIENT) {
            String bedNum = bedManager.getBedNumberByPatientId(id);
            if (bedNum != null) {
                bedManager.releaseBed(bedNum);
                System.out.println("Bed " + bedNum + " released.");
            }
        }
        if (patientManager.deletePatient(id)) {
            System.out.println("Patient deleted successfully.");
        } else {
            System.out.println("Deletion failed.");
        }
    }

    private static void allocateBed() {
        String id = readString("Enter Patient ID to allocate bed: ");
        Patient p = patientManager.findPatientById(id);
        if (p == null) {
            System.out.println("Patient not found.");
            return;
        }
        if (p.getCategory() != PatientCategory.INPATIENT) {
            System.out.println("Only INPATIENTs can be allocated a bed.");
            return;
        }
        // Check if already has a bed
        if (bedManager.getBedNumberByPatientId(id) != null) {
            System.out.println("This patient already has a bed allocated.");
            return;
        }
        String bedNumber = bedManager.allocateBed(id);
        if (bedNumber == null) {
            System.out.println("No available beds in the ward.");
        } else {
            System.out.println("Bed " + bedNumber + " allocated to patient " + id + ".");
            // Update patient to Inpatient with bed info? Actually the patient object is still base Patient; but we can replace with Inpatient.
            // To keep it simple, we replace the patient object with an Inpatient object containing the ward and bed.
            // We need to remove old and add new Inpatient.
            // But we must preserve other details.
            Inpatient inpatient = new Inpatient(
                    p.getPatientId(),
                    p.getFirstName(),
                    p.getLastName(),
                    p.getAge(),
                    p.getGender(),
                    p.getMedicalCondition(),
                    "Ward 1", // fixed ward
                    bedNumber
            );
            // Replace in list
            patientManager.deletePatient(id); // remove old
            try {
                patientManager.registerPatient(inpatient);
            } catch (IllegalArgumentException e) {
                // Should not happen
                System.out.println("Error updating patient to Inpatient.");
            }
            System.out.println("Patient record updated to Inpatient with bed details.");
        }
    }

    private static void releaseBed() {
        String id = readString("Enter Patient ID to release bed: ");
        Patient p = patientManager.findPatientById(id);
        if (p == null) {
            System.out.println("Patient not found.");
            return;
        }
        if (p.getCategory() != PatientCategory.INPATIENT) {
            System.out.println("This patient is not an inpatient.");
            return;
        }
        String bedNumber = bedManager.getBedNumberByPatientId(id);
        if (bedNumber == null) {
            System.out.println("This patient does not have a bed allocated.");
            return;
        }
        boolean released = bedManager.releaseBed(bedNumber);
        if (released) {
            System.out.println("Bed " + bedNumber + " released for patient " + id + ".");
            // Optionally change patient back to a base Patient (without bed info) - for simplicity, we keep as Inpatient but clear bed? Or we can convert.
            // For simplicity, we just convert to base Patient.
            Patient basePatient = new Patient(
                    p.getPatientId(),
                    p.getFirstName(),
                    p.getLastName(),
                    p.getAge(),
                    p.getGender(),
                    p.getMedicalCondition(),
                    PatientCategory.INPATIENT // still inpatient but no bed? Actually if released, they might be discharged? We'll keep as inpatient without bed.
                    // In real system, they may be discharged, but we'll just keep as inpatient without bed for now.
            );
            patientManager.deletePatient(id);
            try {
                patientManager.registerPatient(basePatient);
            } catch (IllegalArgumentException e) {
                // Should not happen
                System.out.println("Error updating patient record.");
            }
        } else {
            System.out.println("Release failed.");
        }
    }

    private static void generateReports() {
        System.out.println("\n----------------- REPORTS -----------------");
        System.out.println("1. Display all registered patients" + patientManager.getTotalPatients());
        System.out.println("2. Display all available beds");
        System.out.println("3. Display all occupied beds");
        System.out.println("4. Display total number of registered patients");
        System.out.println("5. Display total number of occupied beds");
        System.out.println("6. Display ward occupancy percentage");
        System.out.println("7. Display full summary report");
        System.out.println("0. Back to Main Menu");
        System.out.println("----------------------------------------------");
        System.out.print("Enter your choice: ");
        patientManager.displayAllPatients();
        System.out.println("\n--- Bed Status ---");
        System.out.println("Total beds: " + bedManager.getTotalBeds());
        System.out.println("Occupied beds: " + bedManager.getOccupiedCount());
        System.out.println("Available beds: " + (bedManager.getTotalBeds() - bedManager.getOccupiedCount()));
        System.out.printf("Ward occupancy percentage: %.2f%%\n", bedManager.getOccupancyPercentage());
        bedManager.displayWardLayout();
        bedManager.displayAvailableBeds();
        bedManager.displayOccupiedBeds();
    }
}
