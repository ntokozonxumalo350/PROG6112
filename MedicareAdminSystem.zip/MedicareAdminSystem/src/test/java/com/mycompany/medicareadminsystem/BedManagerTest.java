/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.medicareadminsystem;

import java.util.List;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author TRAIN-7166
 */
public class BedManagerTest {
    
    public BedManagerTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of allocateBed method, of class BedManager.
     */
    @Test
    public void testAllocateBed() {
        System.out.println("allocateBed");
        String patientId = "";
        BedManager instance = new BedManager();
        String expResult = "";
        String result = instance.allocateBed(patientId);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of releaseBed method, of class BedManager.
     */
    @Test
    public void testReleaseBed() {
        System.out.println("releaseBed");
        String bedNumber = "";
        BedManager instance = new BedManager();
        boolean expResult = false;
        boolean result = instance.releaseBed(bedNumber);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of releaseBedByPatientId method, of class BedManager.
     */
    @Test
    public void testReleaseBedByPatientId() {
        System.out.println("releaseBedByPatientId");
        String patientId = "";
        BedManager instance = new BedManager();
        boolean expResult = false;
        boolean result = instance.releaseBedByPatientId(patientId);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of displayWardLayout method, of class BedManager.
     */
    @Test
    public void testDisplayWardLayout() {
        System.out.println("displayWardLayout");
        BedManager instance = new BedManager();
        instance.displayWardLayout();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getAvailableBedNumbers method, of class BedManager.
     */
    @Test
    public void testGetAvailableBedNumbers() {
        System.out.println("getAvailableBedNumbers");
        BedManager instance = new BedManager();
        List<String> expResult = null;
        List<String> result = instance.getAvailableBedNumbers();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of displayAvailableBeds method, of class BedManager.
     */
    @Test
    public void testDisplayAvailableBeds() {
        System.out.println("displayAvailableBeds");
        BedManager instance = new BedManager();
        instance.displayAvailableBeds();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getOccupiedBedNumbers method, of class BedManager.
     */
    @Test
    public void testGetOccupiedBedNumbers() {
        System.out.println("getOccupiedBedNumbers");
        BedManager instance = new BedManager();
        List<String> expResult = null;
        List<String> result = instance.getOccupiedBedNumbers();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of displayOccupiedBeds method, of class BedManager.
     */
    @Test
    public void testDisplayOccupiedBeds() {
        System.out.println("displayOccupiedBeds");
        BedManager instance = new BedManager();
        instance.displayOccupiedBeds();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getOccupiedCount method, of class BedManager.
     */
    @Test
    public void testGetOccupiedCount() {
        System.out.println("getOccupiedCount");
        BedManager instance = new BedManager();
        int expResult = 0;
        int result = instance.getOccupiedCount();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getOccupancyPercentage method, of class BedManager.
     */
    @Test
    public void testGetOccupancyPercentage() {
        System.out.println("getOccupancyPercentage");
        BedManager instance = new BedManager();
        double expResult = 0.0;
        double result = instance.getOccupancyPercentage();
        assertEquals(expResult, result, 0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getTotalBeds method, of class BedManager.
     */
    @Test
    public void testGetTotalBeds() {
        System.out.println("getTotalBeds");
        BedManager instance = new BedManager();
        int expResult = 0;
        int result = instance.getTotalBeds();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of isBedOccupied method, of class BedManager.
     */
    @Test
    public void testIsBedOccupied() {
        System.out.println("isBedOccupied");
        String bedNumber = "";
        BedManager instance = new BedManager();
        boolean expResult = false;
        boolean result = instance.isBedOccupied(bedNumber);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getBedNumberByPatientId method, of class BedManager.
     */
    @Test
    public void testGetBedNumberByPatientId() {
        System.out.println("getBedNumberByPatientId");
        String patientId = "";
        BedManager instance = new BedManager();
        String expResult = "";
        String result = instance.getBedNumberByPatientId(patientId);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
