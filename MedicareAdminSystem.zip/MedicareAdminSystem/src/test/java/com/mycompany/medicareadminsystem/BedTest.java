/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.medicareadminsystem;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author TRAIN-7166
 */
public class BedTest {
    
    public BedTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of getBedNumber method, of class Bed.
     */
    @Test
    public void testGetBedNumber() {
        System.out.println("getBedNumber");
        Bed instance = null;
        String expResult = "";
        String result = instance.getBedNumber();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getOccupiedByPatientId method, of class Bed.
     */
    @Test
    public void testGetOccupiedByPatientId() {
        System.out.println("getOccupiedByPatientId");
        Bed instance = null;
        String expResult = "";
        String result = instance.getOccupiedByPatientId();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of isOccupied method, of class Bed.
     */
    @Test
    public void testIsOccupied() {
        System.out.println("isOccupied");
        Bed instance = null;
        boolean expResult = false;
        boolean result = instance.isOccupied();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of occupy method, of class Bed.
     */
    @Test
    public void testOccupy() {
        System.out.println("occupy");
        String patientId = "";
        Bed instance = null;
        instance.occupy(patientId);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of release method, of class Bed.
     */
    @Test
    public void testRelease() {
        System.out.println("release");
        Bed instance = null;
        instance.release();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of toString method, of class Bed.
     */
    @Test
    public void testToString() {
        System.out.println("toString");
        Bed instance = null;
        String expResult = "";
        String result = instance.toString();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
