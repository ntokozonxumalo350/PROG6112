/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.medicareadminsystem;

import java.util.List;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author TRAIN-7166
 */
public class PatientManagerTest {
    
    public PatientManagerTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of registerPatient method, of class PatientManager.
     */
    @Test
    public void testRegisterPatient() {
        System.out.println("registerPatient");
        Patient patient = null;
        PatientManager instance = new PatientManager();
        instance.registerPatient(patient);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of findPatientById method, of class PatientManager.
     */
    @Test
    public void testFindPatientById() {
        System.out.println("findPatientById");
        String patientId = "";
        PatientManager instance = new PatientManager();
        Patient expResult = null;
        Patient result = instance.findPatientById(patientId);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of updatePatient method, of class PatientManager.
     */
    @Test
    public void testUpdatePatient() {
        System.out.println("updatePatient");
        String patientId = "";
        Patient updatedPatient = null;
        PatientManager instance = new PatientManager();
        boolean expResult = false;
        boolean result = instance.updatePatient(patientId, updatedPatient);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of deletePatient method, of class PatientManager.
     */
    @Test
    public void testDeletePatient() {
        System.out.println("deletePatient");
        String patientId = "";
        PatientManager instance = new PatientManager();
        boolean expResult = false;
        boolean result = instance.deletePatient(patientId);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of displayAllPatients method, of class PatientManager.
     */
    @Test
    public void testDisplayAllPatients() {
        System.out.println("displayAllPatients");
        PatientManager instance = new PatientManager();
        instance.displayAllPatients();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getAllPatients method, of class PatientManager.
     */
    @Test
    public void testGetAllPatients() {
        System.out.println("getAllPatients");
        PatientManager instance = new PatientManager();
        List<Patient> expResult = null;
        List<Patient> result = instance.getAllPatients();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getTotalPatients method, of class PatientManager.
     */
    @Test
    public void testGetTotalPatients() {
        System.out.println("getTotalPatients");
        PatientManager instance = new PatientManager();
        int expResult = 0;
        int result = instance.getTotalPatients();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of sortByLastName method, of class PatientManager.
     */
    @Test
    public void testSortByLastName() {
        System.out.println("sortByLastName");
        PatientManager instance = new PatientManager();
        List<Patient> expResult = null;
        List<Patient> result = instance.sortByLastName();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of sortByPatientId method, of class PatientManager.
     */
    @Test
    public void testSortByPatientId() {
        System.out.println("sortByPatientId");
        PatientManager instance = new PatientManager();
        List<Patient> expResult = null;
        List<Patient> result = instance.sortByPatientId();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
